source ~/PA4/PA4.sh
echo ">get lamp";get lamp
echo ">e";e
echo ">n";n
echo ">e";e
echo ">drop lamp";drop lamp
echo ">turn ladder";turn ladder
echo ">w";w
echo ">l";l
echo ">turn ladder";turn ladder
echo ">s";s

