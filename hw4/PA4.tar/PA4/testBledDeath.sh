source ~/PA4/PA4.sh
echo ">get axe";get axe
echo ">break axe";break axe

