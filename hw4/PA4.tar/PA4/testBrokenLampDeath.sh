source ~/PA4/PA4.sh
echo 418 > ~/PA4/comb.txt
echo ">get lamp";get lamp
echo ">drop";drop
echo ">drop -lamp";drop -lamb
echo ">drop lampalamp lamp lampy lamp";drop lampalamp lamp lampy lamp
echo ">drop lamp lampalamp lampy lamp";drop lamp lampalamp lampy lamp
echo ">drop lamp";drop lamp
echo ">drop lamp";drop lamp
echo ">get lamp";get lamp
echo ">e";e
echo ">n";n
echo ">e";e
echo ">get weight";get weight
echo ">drop weight lamp";drop weight lamp
echo ">d";d
echo ">d";d
echo ">nw";nw
echo ">u";u
echo ">get weight";get weight
echo ">d";d
echo ">drop weight";drop weight
echo ">u";u
echo ">nw";nw
echo ">u";u
echo ">get rms";get rms
echo ">get floppy";get floppy
echo ">se";se
echo ">nw";nw
echo ">d";d
echo ">nw";nw
echo ">ne";ne
echo ">w";w
echo ">s";s
echo ">e";e
echo ">turn";turn
echo ">turn floppy";turn floppy
echo ">drop floppy";drop floppy
echo ">turn floppy";turn floppy
echo ">turn dial";turn dial
echo ">turn counterclockwise";turn counterclockwise
echo ">turn dial counterclockwise";turn dial counterclockwise
echo ">turn dial counterclockwise";turn dial counterclockwise
echo ">w";w
echo ">turn dial clockwise";turn dial clockwise
echo ">e";e
echo ">drop lamp";drop lamp
echo ">turn dial clock wise";turn dial clock wise
echo ">turn dial clockwise";turn dial clockwise
echo ">turn dial clockwise";turn dial clockwise
echo ">turn dial clockwise";turn dial clockwise
echo ">w";w
echo ">w";w
echo ">get bracelet";get bracelet
echo ">break axe";break axe
echo ">get axe";get axe
echo ">break paper";break paper
echo ">break shovel";break shovel
echo ">break key";break key
echo ">break dance";break dance
echo ">break dial";break dial
echo ">break";break
echo ">e";e
echo ">e";e
echo ">turn dial counterclockwise";turn dial counterclockwise
echo ">w";w
echo ">w";w
echo ">w";w
echo ">e";e
echo ">e";e
echo ">e";e
echo ">get lamp";get lamp
echo ">w";w
echo ">n";n
echo ">e";e
echo ">get preserver";get preserver
echo ">d";d
echo ">nw";nw
echo ">u";u
echo ">se";se
echo ">d";d
echo ">nw";nw
echo ">nw";nw
echo ">s";s
echo ">s";s
echo ">s";s
echo ">drop preserver";drop preserver
echo ">s";s
echo ">i";i
echo ">put";put
echo ">s";s
echo ">get gold";get gold
echo ">i";i
echo ">e";e
echo ">e";e
echo ">s";s
echo ">s";s
echo ">d";d
echo ">u";u
echo ">put";put
echo ">flush";flush
echo ">n";n
echo ">u";u
echo ">w"; w
echo 123 > ~/PA4/comb.txt
echo ">e"; e
echo ">w"; w
echo 418 > ~/PA4/comb.txt
echo ">w"; w
echo ">e"; e
echo ">w"; w
echo ">i";i
echo ">drop lamp";drop lamp
echo ">break lamp";break lamp
echo ">e"; e
echo ">s"; s

