source ~/PA4/PA4.sh
echo ">get lamp";get lamp
echo ">get e";e
echo ">get e";e
echo ">turn dial clockwise";turn dial clockwise
echo ">turn dial clockwise";turn dial clockwise
echo ">turn dial clockwise";turn dial clockwise
echo ">turn dial clockwise";turn dial clockwise
