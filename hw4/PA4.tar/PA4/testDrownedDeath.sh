source ~/PA4/PA4.sh
echo ">cd ~/_/buttonRoom/.nw/u/se/d/nw/nw/s/s/s";cd ~/_/buttonRoom/.nw/u/se/d/nw/nw/s/s/s
echo ">s";s
echo ">n";n
echo ">n";n


