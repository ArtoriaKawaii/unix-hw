shopt -s expand_aliases
source ~/PA2/PA2.sh
(cd ~/_/receivingRoom/e/n/e;tail -1 p* >T;mv T preserver)
echo '>e';e
echo '>n';n
echo '>e';e
echo '>x weight';x weight
echo '>x ladder';x ladder
echo '>x preserver';x preserver
echo '>x life';x life
echo '>d';d
echo '>nw';nw
echo '>u';u
echo '>d';d
echo '>x button';x button
echo '>press button';press button
echo '>nw';nw
echo '>press ladder';press ladder
echo '>x ladder';x ladder
echo '>press lamp';press lamp
echo '>x lamp';x lamp
echo '>drop weight';drop weight
echo '>dropweight';dropweight
echo '>u';u
echo '>getall';getall
echo '>dropweight';dropweight
echo '>d';d
echo '>u';u
echo '>getall';getall
echo '>d';d
echo '>dropweight';dropweight
echo '>l';l
echo '>i';i
echo '>u';u
echo '>getall';getall
echo '>u';u
echo '>nw';nw
echo '>u';u
echo '>getall';getall
echo '>se';se
echo '>d';d
echo '>nw';nw
echo '>ne';ne
echo '>w';w
echo '>s';s
echo '>w';w
echo '>getall';getall
echo '>e';e
echo '>n';n
echo '>e';e
echo '>d';d
echo '>nw';nw
echo '>u';u
echo '>se';se
echo '>d';d
echo '>nw';nw
echo '>nw';nw
echo '>s';s
echo '>s';s
echo '>x lake';x lake
echo '>s';s
echo '>s';s
echo '>x chute';x chute
echo '>n';n
echo '>put';put
echo '>score';score
echo '>i';i
echo '>s';s
echo '>put';put
echo '>put';put
echo '>n';n
echo '>put';put
echo '>i';i
echo '>score';score
echo '>ls ~/PA2/rooms';ls ~/PA2/rooms
echo '>cd ~/PA2/rooms/treasureRoom/';cd ~/PA2/rooms/treasureRoom/
echo '>ls';ls
echo '>l';l
echo '>n';n
echo '>s';s
echo '>s';s
echo '>n';n
echo '>basename `pwd`';basename `pwd`
echo '>getall';getall
echo '>e';e
echo '>e';e
echo '>s';s
echo '>d';d
echo '>i';i
echo '>score';score
echo '>put';put
echo '>score';score
echo '>i';i
echo '>ls ~/PA2/rooms/treasureRoom/';ls ~/PA2/rooms/treasureRoom/
echo '>l';l
echo '>getall';getall
echo '>ls ~/PA2/rooms/treasureRoom/';ls ~/PA2/rooms/treasureRoom/
echo '>score';score
echo '>flush';flush
echo '>ls ~/PA2/rooms/treasureRoom/';ls ~/PA2/rooms/treasureRoom/
echo '>mv ~/PA2/rooms/i/i/* ~/PA2/rooms/treasureRoom/';mv ~/PA2/rooms/i/i/* ~/PA2/rooms/treasureRoom/
echo '>ls ~/PA2/rooms/treasureRoom/';ls ~/PA2/rooms/treasureRoom/
echo '>i';i
echo '>score';score
echo '>mv ~/PA2/rooms/treasureRoom/[^9d]* ~/PA2/rooms/i/i';mv ~/PA2/rooms/treasureRoom/[^9d]* ~/PA2/rooms/i/i
echo '>ls ~/PA2/rooms/treasureRoom/';ls ~/PA2/rooms/treasureRoom/
echo '>i';i
echo '>score';score
echo '> ls ~/PA2/rooms/i/i'; ls ~/PA2/rooms/i/i
echo '>put';put
echo '> ls ~/PA2/rooms/i/i'; ls ~/PA2/rooms/i/i
echo '> ls ~/PA2/rooms/treasureRoom'; ls ~/PA2/rooms/treasureRoom
echo '> ls'; ls
echo '>l';l
echo '>ls';ls
echo '>getall';getall
