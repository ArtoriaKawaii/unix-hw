ls ~/X &> /dev/null || ln -s /dev/null ~/X
ls ~/_ &> /dev/null || ln -s ~/PA2/rooms ~/_
cd ~/PA2;sudo rm -rf rooms; tar -xf rooms.tar
cd rooms/receivingRoom;PS1=">"

alias x='cat'
alias score='echo You have scored `(cd ~/_/treasureRoom/; ls [bdgps][ilor][al][cdmtv]* 2> ~/X | wc -w)`0 points.'
alias quit='score; exit'
alias nogo='echo You cannot go that way.'
alias n='basename `pwd -P` | fgrep -w "s" - &> ~/X && cd `pwd -P` && cd .. || cd n &> ~/X && disp || nogo'
alias s='basename `pwd -P` | fgrep -w "n" - &> ~/X && cd `pwd -P` && cd .. || cd s &> ~/X && disp || nogo'
alias e='basename `pwd -P` | fgrep -w "w" - &> ~/X && cd `pwd -P` && cd .. || cd e &> ~/X && disp || nogo'
alias w='basename `pwd -P` | fgrep -w "e" - &> ~/X && cd `pwd -P` && cd .. || cd w &> ~/X && disp || nogo'
alias nw='basename `pwd -P` | fgrep -w "se" - &> ~/X && cd `pwd -P` && cd .. || cd nw &> ~/X && disp || nogo'
alias sw='basename `pwd -P` | fgrep -w "ne" - &> ~/X && cd `pwd -P` && cd .. || cd sw&>~/X && disp || nogo'
alias d='basename `pwd -P` | fgrep -w "u" - &> ~/X && cd `pwd -P` && cd .. || cd d &> ~/X && disp || nogo'
alias ne='echo `ls` | fgrep -vw "ne" - &> ~/X && basename `pwd -P` | fgrep -w "sw" &> ~/X && cd .. || cd ne &> ~/X && disp || nogo'
alias se='echo `ls` | fgrep -vw "se" - &> ~/X && basename `pwd -P` | fgrep -w "nw" &> ~/X && cd .. || cd se &> ~/X && disp || nogo'
alias u='echo `ls` | fgrep -vw "u" - &> ~/X && basename `pwd -P` | fgrep -w "d" &> ~/X && cd .. || cd u &> ~/X && disp || nogo'

alias l='mv 1 9 &> ~/X; disp'
alias disp='(echo `(cd ..; pwd)` | fgrep -e `pwd -P` &> ~/X && cd .. || echo "must do" &> ~/X ) && (ls "9" &> ~/X && head -n9 ./description || head -n1 ./description;(mv 9 1 &> ~/X; dispmessages))'
alias dispmessages='fgrep -hw `ls | paste ~/_/es - | cut --complement -c4` -h ~/_/There | cut -d";" -f1; echo junk > ~/X'

alias i='echo You currently have:;(cd ~/_/i/i; ls | xargs -n1 echo "A" | fgrep -vx "A" - )'
alias getall='mv *[agkorvw][celmptx][deiloprsy]* ~/_/i/_ &> ~/X || echo Nothing to take.; (cd ~/_/i/_; ls | xargs -n1 echo "Taken: a" | fgrep -vx "Taken: a" -) && mv ~/_/i/_/* ~/_/i/i &> ~/X'
alias dropweight='ls ~/_/i/i/"weight" &> ~/X && pwd -P | fgrep "/PA2/rooms/receivingRoom/e/n/e/d" - &> ~/X && (cd .. && mv d .d && ln -s ~/_/buttonRoom/ d) && cd ~/_/buttonRoom/; (ls ~/_/i/i/"weight" &> ~/X || echo "You do not have that."; ls ~/_/i/i/"weight" &> ~/X && mv ~/_/i/i/weight ./ && echo "Done." && pwd -P | fgrep "/PA2/rooms/buttonRoom" - &> ~/X && echo "A passageway opens.") 2> ~/X'
alias press='(cat | fgrep --color=never -C9 "press" - 2> ~/X || echo "You cannot press that.") <'
alias put='echo `ls` | fgrep -vw -e"chute" -e"urinal" - &> ~/X && echo "Nothing to put treasures into." || ls ~/_/i/i/[bdgps][ilor][al][cdmtv]* &> ~/X || echo "No treasure to put into it."; ls [cu][hr][ui][tn][ea]* &> ~/X && ls ~/_/i/i/[bdgps][ilor][al][cdmtv]* &> ~/X && ls "chute" &> ~/X && echo "You hear it slide down the chute and off into the distance." && mv ~/_/i/i/[bdgps][ilor][al][cdmtv]* ~/_/treasureRoom/ &> ~/X && score; ls [cu][hr][ui][tn][ea]* &> ~/X && ls ~/_/i/i/[bdgps][ilor][al][cdmtv]* &> ~/X && ls "urinal" &> ~/X && echo "You hear it plop down in some water below." && mv ~/_/i/i/[bdgps][ilor][al][cdmtv]* ~/_/ &> ~/X'
alias flush='ls "urinal" &> ~/X && echo "Whoooosh!!" || echo "I see nothing to flush."; mv ~/_/[bdgps][ilor][al][cdmtv]* ~/PA2/rooms/treasureRoom/ &> ~/X && score'

l
