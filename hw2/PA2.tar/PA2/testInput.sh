shopt -s expand_aliases
source ~/PA2/PA2.sh
echo ">x lamp";x lamp
echo ">x shovel";x shovel
echo ">e";e
echo ">n";n
echo ">e";e
echo ">i";i
echo ">getall";getall
echo ">i";i
echo ">d";d
echo ">cd ../../../../../buttonRoom";cd ../../../../../buttonRoom
echo ">l";l
echo ">nw";nw
echo ">u";u
echo ">se";se
echo ">d";d
echo ">nw";nw
echo ">nw";nw
echo ">s";s
echo ">s";s
echo ">s";s
echo ">s";s
echo ">s";s
echo ">getall";getall
echo ">i";i
echo ">e";e
echo ">e";e
echo ">n";n
echo ">d";d
echo ">s";s
echo ">flush";flush
echo ">put";put
echo ">i";i
echo ">score";score
echo ">flush";flush
echo ">quit";quit
