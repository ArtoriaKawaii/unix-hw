sed 's,cantmove w,& < ~/PA3/comb.txt,' <~/PA3/PA3.sh >~/PA3/PA3.temp.sh
chmod u+x ~/PA3/PA3.temp.sh
source ~/PA3/PA3.temp.sh
rm -f ~/PA3/PA3.temp.sh
cp ~/PA3/comb.wrong ~/PA3/comb.txt
echo ">get lamp";get lamp
echo ">e";e
echo ">n";n
echo ">e";e
echo ">get weight";get weight
echo ">drop weight";drop weight
echo ">d";d
echo ">d";d
echo ">nw";nw
echo ">u";u
echo ">get weight";get weight
echo ">d";d
echo ">drop weight";drop weight
echo ">u";u
echo ">nw";nw
echo ">u";u
echo ">get rms";get rms
echo ">get floppy";get floppy
echo ">se";se
echo ">nw";nw
echo ">d";d
echo ">nw";nw
echo ">ne";ne
echo ">w";w
echo ">s";s
echo ">e";e
echo ">drop floppy";drop floppy
echo ">w";w
echo ">e";e
echo ">drop lamp";drop lamp
echo ">w";w
echo ">w";w
echo ">get bracelet";get bracelet
echo ">drop";drop
echo ">drop axe";drop axe
echo ">break";break
echo ">get axe";get axe
echo ">break paper";break paper
echo ">break shovel";break shovel
echo ">break key";break key
echo ">break dial";break dial
echo ">e";e
echo ">e";e
echo ">w";w
echo ">w";w
echo ">w";w
echo ">e";e
echo ">e";e
echo ">e";e
echo ">get lamp";get lamp
echo ">w";w
echo ">n";n
echo ">e";e
echo ">get preserver";get preserver
echo ">d";d
echo ">nw";nw
echo ">u";u
echo ">se";se
echo ">d";d
echo ">nw";nw
echo ">nw";nw
echo ">s";s
echo ">s";s
echo ">s";s
echo ">drop preserver";drop preserver
echo ">s";s
echo ">i";i
echo ">put";put
echo ">s";s
echo ">get gold";get gold
echo ">i";i
echo ">e";e
echo ">e";e
echo ">s";s
echo ">s";s
echo ">d";d
echo ">u";u
echo ">put";put
echo ">flush";flush
echo ">n";n
echo ">u";u
echo ">drop lamp";drop lamp
echo ">w";w
cp ~/PA3/comb.right ~/PA3/comb.txt
echo ">w";w
echo ">i";i
echo ">break lamp";break lamp
echo ">break cable";break cable
